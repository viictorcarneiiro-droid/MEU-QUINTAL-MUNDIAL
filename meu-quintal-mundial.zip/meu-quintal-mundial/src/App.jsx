import React, { useState } from 'react'
import { Routes, Route } from 'react-router-dom'
import Login from './components/Login.jsx'
import Layout from './components/Layout.jsx'
import Dashboard from './components/Dashboard.jsx'
import Lancamentos from './components/Lancamentos.jsx'
import Viagens from './components/Viagens.jsx'
import Metas from './components/Metas.jsx'
import Relatorio from './components/Relatorio.jsx'
import { isUnlocked } from './lib/storage'

export default function App() {
  const [unlocked, setUnlocked] = useState(isUnlocked())

  if (!unlocked) {
    return <Login onUnlock={() => setUnlocked(true)} />
  }

  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Dashboard />} />
        <Route path="lancamentos" element={<Lancamentos />} />
        <Route path="viagens" element={<Viagens />} />
        <Route path="metas" element={<Metas />} />
        <Route path="relatorio" element={<Relatorio />} />
      </Route>
    </Routes>
  )
}
