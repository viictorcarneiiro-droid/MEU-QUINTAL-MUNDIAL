import React, { useMemo, useState } from 'react'
import { getLancamentos, getViagens } from '../lib/storage'
import {
  fmtMoeda, totais, filtrarPorMes, mesAtualISO, nomeMesLongo,
  agruparPor, ultimosNMeses, nomeMes,
} from '../lib/calc'

export default function Relatorio() {
  const [mesISO, setMesISO] = useState(mesAtualISO())
  const lancamentos = getLancamentos()
  const viagens = getViagens()

  const meses6 = ultimosNMeses(12)
  const doMes = useMemo(() => filtrarPorMes(lancamentos, mesISO), [lancamentos, mesISO])
  const t = totais(doMes)

  const mesAnteriorISO = useMemo(() => {
    const [a, m] = mesISO.split('-').map(Number)
    const d = new Date(a, m - 2, 1)
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
  }, [mesISO])
  const tAnterior = totais(filtrarPorMes(lancamentos, mesAnteriorISO))

  const porCategoriaEntrada = useMemo(() => {
    const g = agruparPor(doMes.filter(l => l.tipo === 'entrada'), 'categoria')
    return Object.entries(g).map(([nome, v]) => ({ nome, valor: v.entradas })).sort((a, b) => b.valor - a.valor)
  }, [doMes])

  const porCategoriaSaida = useMemo(() => {
    const g = agruparPor(doMes.filter(l => l.tipo === 'saida'), 'categoria')
    return Object.entries(g).map(([nome, v]) => ({ nome, valor: v.saidas })).sort((a, b) => b.valor - a.valor)
  }, [doMes])

  const porCaixa = useMemo(() => {
    const g = agruparPor(doMes, 'caixa')
    return Object.entries(g).map(([nome, v]) => ({ nome, entradas: v.entradas, saidas: v.saidas }))
  }, [doMes])

  const porCidade = useMemo(() => {
    const g = agruparPor(doMes.filter(l => l.cidade), 'cidade')
    return Object.entries(g).map(([nome, v]) => ({ nome, entradas: v.entradas, saidas: v.saidas }))
  }, [doMes])

  const cidadesVisitadasNoMes = useMemo(() => {
    return viagens.filter(v => v.chegada?.slice(0, 7) === mesISO || v.saida?.slice(0, 7) === mesISO).length
  }, [viagens, mesISO])

  const diasComLancamento = new Set(doMes.map(l => l.data)).size
  const diasNoMes = new Date(Number(mesISO.slice(0, 4)), Number(mesISO.slice(5, 7)), 0).getDate()
  const custoMedioDiario = diasComLancamento > 0 ? t.saidas / diasNoMes : 0

  const maioresDespesas = [...doMes.filter(l => l.tipo === 'saida')].sort((a, b) => b.valor - a.valor).slice(0, 5)

  const variacao = (atual, anterior) => {
    if (anterior === 0) return atual > 0 ? 100 : 0
    return ((atual - anterior) / anterior) * 100
  }

  return (
    <div className="p-6 md:p-8 max-w-5xl">
      <header className="no-print flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-signal-cyan font-mono-num text-xs tracking-wider mb-1">RELATÓRIO REAL DA SUA VIDA</p>
          <h2 className="font-display text-2xl font-semibold">{nomeMesLongo(mesISO)}</h2>
        </div>
        <div className="flex gap-3 items-center">
          <select value={mesISO} onChange={e => setMesISO(e.target.value)} className="!w-44">
            {meses6.slice().reverse().map(m => <option key={m} value={m}>{nomeMesLongo(m)}</option>)}
          </select>
          <button
            onClick={() => window.print()}
            className="bg-signal-cyan text-base-950 text-sm font-semibold px-4 py-2 rounded-lg hover:opacity-90 transition"
          >
            Imprimir / salvar PDF
          </button>
        </div>
      </header>

      <div className="hidden print:block mb-6">
        <h1 className="text-2xl font-bold">Meu Quintal Mundial — Relatório de {nomeMesLongo(mesISO)}</h1>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Receitas', valor: t.entradas, vs: variacao(t.entradas, tAnterior.entradas) },
          { label: 'Despesas', valor: t.saidas, vs: variacao(t.saidas, tAnterior.saidas) },
          { label: 'Lucro', valor: t.saldo, vs: variacao(t.saldo, tAnterior.saldo) },
          { label: 'Margem', valor: null, texto: `${t.margem.toFixed(1)}%` },
        ].map((c, i) => (
          <div key={i} className="panel p-4">
            <p className="text-[11px] uppercase tracking-wide text-base-500 font-mono-num">{c.label}</p>
            <p className="font-mono-num text-xl font-semibold mt-1">{c.texto || fmtMoeda(c.valor)}</p>
            {c.vs !== undefined && (
              <p className={`text-[11px] mt-1 font-mono-num ${c.vs >= 0 ? 'text-signal-cyan' : 'text-signal-red'}`}>
                {c.vs >= 0 ? '▲' : '▼'} {Math.abs(c.vs).toFixed(0)}% vs mês anterior
              </p>
            )}
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-5">
        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">RECEITAS POR TIPO DE SERVIÇO</p>
          {porCategoriaEntrada.length === 0 ? (
            <p className="text-sm text-base-500 py-4 text-center">Sem receitas no período.</p>
          ) : (
            <div className="space-y-2">
              {porCategoriaEntrada.map((c, i) => (
                <Barra key={i} nome={c.nome} valor={c.valor} max={porCategoriaEntrada[0].valor} cor="#4DD9C7" />
              ))}
            </div>
          )}
        </div>

        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">DESPESAS POR CATEGORIA</p>
          {porCategoriaSaida.length === 0 ? (
            <p className="text-sm text-base-500 py-4 text-center">Sem despesas no período.</p>
          ) : (
            <div className="space-y-2">
              {porCategoriaSaida.map((c, i) => (
                <Barra key={i} nome={c.nome} valor={c.valor} max={porCategoriaSaida[0].valor} cor="#F2554B" />
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-5">
        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">RESULTADO POR CAIXA</p>
          {porCaixa.length === 0 ? (
            <p className="text-sm text-base-500 py-4 text-center">Sem lançamentos no período.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-base-500 text-left">
                  <th className="font-normal pb-2">Caixa</th>
                  <th className="font-normal pb-2 text-right">Entradas</th>
                  <th className="font-normal pb-2 text-right">Saídas</th>
                </tr>
              </thead>
              <tbody>
                {porCaixa.map((c, i) => (
                  <tr key={i} className="border-t border-base-700">
                    <td className="py-1.5">{c.nome}</td>
                    <td className="py-1.5 text-right font-mono-num text-signal-cyan">{fmtMoeda(c.entradas)}</td>
                    <td className="py-1.5 text-right font-mono-num text-signal-red">{fmtMoeda(c.saidas)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">RESULTADO POR CIDADE</p>
          {porCidade.length === 0 ? (
            <p className="text-sm text-base-500 py-4 text-center">Nenhum lançamento com cidade marcada.</p>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-[11px] text-base-500 text-left">
                  <th className="font-normal pb-2">Cidade</th>
                  <th className="font-normal pb-2 text-right">Entradas</th>
                  <th className="font-normal pb-2 text-right">Saídas</th>
                </tr>
              </thead>
              <tbody>
                {porCidade.map((c, i) => (
                  <tr key={i} className="border-t border-base-700">
                    <td className="py-1.5">{c.nome}</td>
                    <td className="py-1.5 text-right font-mono-num text-signal-cyan">{fmtMoeda(c.entradas)}</td>
                    <td className="py-1.5 text-right font-mono-num text-signal-red">{fmtMoeda(c.saidas)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-5">
        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">TOP 5 MAIORES DESPESAS</p>
          {maioresDespesas.length === 0 ? (
            <p className="text-sm text-base-500 py-4 text-center">Sem despesas registradas.</p>
          ) : (
            <div className="space-y-2">
              {maioresDespesas.map(d => (
                <div key={d.id} className="flex justify-between text-sm border-b border-base-700 last:border-0 pb-1.5 last:pb-0">
                  <span>{d.categoria} <span className="text-base-500">· {new Date(d.data + 'T00:00').toLocaleDateString('pt-BR')}</span></span>
                  <span className="font-mono-num text-signal-red">{fmtMoeda(d.valor)}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">RESUMO OPERACIONAL DO MÊS</p>
          <div className="grid grid-cols-2 gap-y-2 text-sm">
            <span className="text-base-500">Dias com lançamento</span>
            <span className="text-right font-mono-num">{diasComLancamento} de {diasNoMes}</span>
            <span className="text-base-500">Custo médio diário</span>
            <span className="text-right font-mono-num">{fmtMoeda(custoMedioDiario)}</span>
            <span className="text-base-500">Cidades na jornada</span>
            <span className="text-right font-mono-num">{cidadesVisitadasNoMes}</span>
            <span className="text-base-500">Ticket médio (entradas)</span>
            <span className="text-right font-mono-num">
              {fmtMoeda(doMes.filter(l => l.tipo === 'entrada').length ? t.entradas / doMes.filter(l => l.tipo === 'entrada').length : 0)}
            </span>
          </div>
        </div>
      </div>

      <div className="panel p-5 text-sm text-base-500 leading-relaxed">
        Em {nomeMesLongo(mesISO)}, o saldo do período foi de{' '}
        <span className={`font-mono-num ${t.saldo >= 0 ? 'text-signal-cyan' : 'text-signal-red'}`}>{fmtMoeda(t.saldo)}</span>
        , com margem de <span className="font-mono-num text-white">{t.margem.toFixed(1)}%</span>. Continue registrando todos os
        lançamentos para que esse retrato fique cada vez mais completo.
      </div>
    </div>
  )
}

function Barra({ nome, valor, max, cor }) {
  const pct = max > 0 ? (valor / max) * 100 : 0
  return (
    <div>
      <div className="flex justify-between text-xs mb-1">
        <span className="text-white">{nome}</span>
        <span className="font-mono-num text-base-500">{fmtMoeda(valor)}</span>
      </div>
      <div className="h-1.5 rounded-full bg-base-700 overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: cor }} />
      </div>
    </div>
  )
}
