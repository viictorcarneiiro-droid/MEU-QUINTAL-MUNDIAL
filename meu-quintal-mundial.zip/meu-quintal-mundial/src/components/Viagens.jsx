import React, { useMemo, useState } from 'react'
import { getViagens, addViagem, removeViagem, getLancamentos } from '../lib/storage'
import { fmtMoeda } from '../lib/calc'

function vazio() {
  return { cidade: '', estado: '', pais: 'Brasil', chegada: '', saida: '', hospedagem: '', observacao: '' }
}

export default function Viagens() {
  const [viagens, setViagens] = useState(getViagens())
  const [form, setForm] = useState(vazio())
  const lancamentos = getLancamentos()

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.cidade) return
    const novo = addViagem({ ...form, hospedagem: Number(form.hospedagem) || 0 })
    setViagens(prev => [...prev, novo])
    setForm(vazio())
  }

  function handleRemover(id) {
    removeViagem(id)
    setViagens(prev => prev.filter(v => v.id !== id))
  }

  const linhas = useMemo(() => {
    return viagens.map(v => {
      const ligados = lancamentos.filter(l => l.cidade?.toLowerCase().trim() === v.cidade.toLowerCase().trim())
      const faturamento = ligados.filter(l => l.tipo === 'entrada').reduce((s, l) => s + Number(l.valor), 0)
      const gastosLigados = ligados.filter(l => l.tipo === 'saida').reduce((s, l) => s + Number(l.valor), 0)
      const dias = v.chegada && v.saida
        ? Math.max(1, Math.round((new Date(v.saida) - new Date(v.chegada)) / 86400000) + 1)
        : null
      const custoTotal = gastosLigados + (v.hospedagem || 0)
      const lucro = faturamento - custoTotal
      return { ...v, faturamento, custoTotal, lucro, dias }
    }).sort((a, b) => (a.chegada < b.chegada ? 1 : -1))
  }, [viagens, lancamentos])

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6">
        <p className="text-signal-cyan font-mono-num text-xs tracking-wider mb-1">MINHA JORNADA</p>
        <h2 className="font-display text-2xl font-semibold">Cidades e viagens</h2>
        <p className="text-sm text-base-500 mt-1">
          Quanto uma cidade custou versus quanto ela gerou — os lançamentos com o mesmo nome de cidade se conectam automaticamente.
        </p>
      </header>

      <div className="grid lg:grid-cols-[320px_1fr] gap-5">
        <form onSubmit={handleSubmit} className="panel p-5 space-y-3 h-fit">
          <div>
            <label className="block text-xs text-base-500 mb-1.5">Cidade</label>
            <input value={form.cidade} onChange={e => setForm({ ...form, cidade: e.target.value })} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-base-500 mb-1.5">Estado</label>
              <input value={form.estado} onChange={e => setForm({ ...form, estado: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-base-500 mb-1.5">País</label>
              <input value={form.pais} onChange={e => setForm({ ...form, pais: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-base-500 mb-1.5">Chegada</label>
              <input type="date" value={form.chegada} onChange={e => setForm({ ...form, chegada: e.target.value })} />
            </div>
            <div>
              <label className="block text-xs text-base-500 mb-1.5">Saída</label>
              <input type="date" value={form.saida} onChange={e => setForm({ ...form, saida: e.target.value })} />
            </div>
          </div>
          <div>
            <label className="block text-xs text-base-500 mb-1.5">Custo de hospedagem (R$)</label>
            <input type="number" step="0.01" value={form.hospedagem} onChange={e => setForm({ ...form, hospedagem: e.target.value })} />
          </div>
          <div>
            <label className="block text-xs text-base-500 mb-1.5">Observação</label>
            <textarea rows={2} value={form.observacao} onChange={e => setForm({ ...form, observacao: e.target.value })} />
          </div>
          <button type="submit" className="w-full bg-signal-cyan text-base-950 font-semibold py-2.5 rounded-lg hover:opacity-90 transition">
            Adicionar cidade
          </button>
        </form>

        <div className="space-y-3">
          {linhas.length === 0 ? (
            <div className="panel p-10 text-center text-sm text-base-500">Nenhuma cidade cadastrada ainda.</div>
          ) : (
            linhas.map(v => (
              <div key={v.id} className="panel p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-display font-semibold text-white">{v.cidade}{v.estado ? `, ${v.estado}` : ''}</p>
                    <p className="text-[11px] text-base-500 font-mono-num mt-0.5">
                      {v.chegada ? new Date(v.chegada + 'T00:00').toLocaleDateString('pt-BR') : '—'}
                      {' → '}
                      {v.saida ? new Date(v.saida + 'T00:00').toLocaleDateString('pt-BR') : '—'}
                      {v.dias ? ` · ${v.dias} dia(s)` : ''}
                    </p>
                  </div>
                  <button onClick={() => handleRemover(v.id)} className="text-xs text-base-500 hover:text-signal-red">remover</button>
                </div>

                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div>
                    <p className="text-[11px] text-base-500">Faturamento gerado</p>
                    <p className="font-mono-num text-signal-cyan">{fmtMoeda(v.faturamento)}</p>
                  </div>
                  <div>
                    <p className="text-[11px] text-base-500">Custo total (hospedagem + gastos)</p>
                    <p className="font-mono-num text-signal-red">{fmtMoeda(v.custoTotal)}</p>
                  </div>
                  <div>
                    <p className="text-[11px] text-base-500">Resultado</p>
                    <p className={`font-mono-num ${v.lucro >= 0 ? 'text-signal-cyan' : 'text-signal-red'}`}>{fmtMoeda(v.lucro)}</p>
                  </div>
                </div>
                {v.observacao && <p className="text-xs text-base-500 mt-3">{v.observacao}</p>}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
