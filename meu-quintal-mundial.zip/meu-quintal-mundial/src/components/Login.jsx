import React, { useEffect, useState } from 'react'
import { hasPassword, setPassword, checkPassword, unlock } from '../lib/storage'

export default function Login({ onUnlock }) {
  const [modo, setModo] = useState('carregando') // 'criar' | 'entrar'
  const [senha, setSenha] = useState('')
  const [confirmar, setConfirmar] = useState('')
  const [erro, setErro] = useState('')

  useEffect(() => {
    hasPassword().then(existe => setModo(existe ? 'entrar' : 'criar'))
  }, [])

  async function handleCriar(e) {
    e.preventDefault()
    if (senha.length < 4) return setErro('Use pelo menos 4 caracteres.')
    if (senha !== confirmar) return setErro('As senhas não coincidem.')
    await setPassword(senha)
    unlock()
    onUnlock()
  }

  async function handleEntrar(e) {
    e.preventDefault()
    const ok = await checkPassword(senha)
    if (!ok) return setErro('Senha incorreta.')
    unlock()
    onUnlock()
  }

  return (
    <div className="min-h-screen bg-base-950 control-grid flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-signal-cyan/10 blur-3xl" />
      <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-signal-blue/10 blur-3xl" />

      <div className="relative w-full max-w-sm">
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 text-signal-cyan font-mono-num text-xs tracking-wider mb-3">
            <span className="w-1.5 h-1.5 rounded-full bg-signal-cyan animate-pulse" />
            ACESSO RESTRITO
          </div>
          <h1 className="font-display text-2xl font-semibold text-white">Meu Quintal Mundial</h1>
          <p className="text-base-500 text-sm mt-1">Torre de controle pessoal — uso exclusivo</p>
        </div>

        <form
          onSubmit={modo === 'criar' ? handleCriar : handleEntrar}
          className="panel panel-glow p-6 space-y-4"
        >
          {modo === 'criar' && (
            <p className="text-xs text-base-500 leading-relaxed">
              Primeiro acesso: crie uma senha local. Ela protege a entrada no app neste
              navegador — os dados ficam salvos apenas neste dispositivo.
            </p>
          )}

          <div>
            <label className="block text-xs text-base-500 mb-1.5">Senha</label>
            <input
              type="password"
              value={senha}
              onChange={e => setSenha(e.target.value)}
              autoFocus
              required
            />
          </div>

          {modo === 'criar' && (
            <div>
              <label className="block text-xs text-base-500 mb-1.5">Confirmar senha</label>
              <input
                type="password"
                value={confirmar}
                onChange={e => setConfirmar(e.target.value)}
                required
              />
            </div>
          )}

          {erro && <p className="text-signal-red text-xs">{erro}</p>}

          <button
            type="submit"
            className="w-full bg-signal-cyan text-base-950 font-semibold py-2.5 rounded-lg hover:opacity-90 transition"
          >
            {modo === 'criar' ? 'Criar acesso' : 'Entrar'}
          </button>
        </form>

        <p className="text-center text-[11px] text-base-500 mt-6 leading-relaxed">
          Este é um bloqueio local do navegador, não uma autenticação de servidor.
          Quem tiver acesso físico ao dispositivo pode limpar os dados do site.
        </p>
      </div>
    </div>
  )
}
