import React, { useRef } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { lock, exportarTudo, importarTudo } from '../lib/storage'

const NAV = [
  { to: '/', label: 'Dashboard', icon: '◆' },
  { to: '/lancamentos', label: 'Lançamentos', icon: '⇄' },
  { to: '/viagens', label: 'Minha Jornada', icon: '◎' },
  { to: '/metas', label: 'Metas', icon: '▲' },
  { to: '/relatorio', label: 'Relatório', icon: '▤' },
]

export default function Layout() {
  const agora = new Date()
  const fileInput = useRef(null)

  function handleExportar() {
    const dados = exportarTudo()
    const blob = new Blob([JSON.stringify(dados, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `meu-quintal-mundial-backup-${agora.toISOString().slice(0, 10)}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  function handleImportarArquivo(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = () => {
      try {
        const dados = JSON.parse(reader.result)
        importarTudo(dados)
        window.location.reload()
      } catch {
        alert('Arquivo inválido.')
      }
    }
    reader.readAsText(file)
  }

  return (
    <div className="min-h-screen bg-base-950 control-grid text-white flex">
      <aside className="no-print w-60 shrink-0 border-r border-base-700 bg-base-900/60 backdrop-blur flex flex-col">
        <div className="px-5 py-5 border-b border-base-700">
          <div className="flex items-center gap-2 text-signal-cyan font-mono-num text-[11px] tracking-wider">
            <span className="w-1.5 h-1.5 rounded-full bg-signal-cyan animate-pulse" />
            ONLINE
          </div>
          <h1 className="font-display font-semibold text-base mt-1.5 leading-tight">
            Meu Quintal<br />Mundial
          </h1>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/'}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition ${
                  isActive
                    ? 'bg-signal-cyan/10 text-signal-cyan border border-signal-cyan/30'
                    : 'text-base-500 hover:text-white hover:bg-base-800 border border-transparent'
                }`
              }
            >
              <span className="font-mono-num text-xs">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="px-5 py-4 border-t border-base-700 text-[11px] text-base-500 font-mono-num space-y-2">
          <p>{agora.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}</p>
          <div className="flex gap-3">
            <button onClick={handleExportar} className="hover:text-signal-cyan transition">↓ Backup</button>
            <button onClick={() => fileInput.current?.click()} className="hover:text-signal-cyan transition">↑ Restaurar</button>
          </div>
          <input ref={fileInput} type="file" accept="application/json" className="hidden" onChange={handleImportarArquivo} />
          <button
            onClick={() => { lock(); window.location.reload() }}
            className="text-signal-red/80 hover:text-signal-red transition block"
          >
            ⏻ Bloquear sessão
          </button>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <Outlet />
      </main>
    </div>
  )
}
