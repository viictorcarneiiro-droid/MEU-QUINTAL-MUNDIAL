import React, { useMemo, useState } from 'react'
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, PieChart, Pie, Cell } from 'recharts'
import { getLancamentos, getMetas, getPerfil, savePerfil } from '../lib/storage'
import { fmtMoeda, totais, filtrarPorMes, mesAtualISO, ultimosNMeses, nomeMes, agruparPor } from '../lib/calc'

const CORES_CAIXA = {
  Negócio: '#4C8DFF',
  Pessoal: '#4DD9C7',
  Reserva: '#F2B84B',
  Investimento: '#B085F5',
  Viagem: '#F2554B',
}

function Card({ label, value, sub, accent }) {
  return (
    <div className="panel p-4">
      <p className="text-[11px] uppercase tracking-wide text-base-500 font-mono-num">{label}</p>
      <p className={`font-mono-num text-2xl font-semibold mt-1.5 ${accent || 'text-white'}`}>{value}</p>
      {sub && <p className="text-xs text-base-500 mt-1">{sub}</p>}
    </div>
  )
}

export default function Dashboard() {
  const lancamentos = getLancamentos()
  const metas = getMetas()
  const [perfil, setPerfil] = useState(getPerfil())
  const mesISO = mesAtualISO()

  const doMes = useMemo(() => filtrarPorMes(lancamentos, mesISO), [lancamentos, mesISO])
  const totalGeral = useMemo(() => totais(lancamentos), [lancamentos])
  const totalMes = useMemo(() => totais(doMes), [doMes])

  const serieMeses = useMemo(() => {
    return ultimosNMeses(6).map(m => {
      const t = totais(filtrarPorMes(lancamentos, m))
      return { mes: nomeMes(m), Entradas: Math.round(t.entradas), Saídas: Math.round(t.saidas) }
    })
  }, [lancamentos])

  const porCaixa = useMemo(() => {
    const grupos = agruparPor(doMes, 'caixa')
    return Object.entries(grupos)
      .map(([nome, v]) => ({ nome, valor: v.entradas + v.saidas }))
      .filter(g => g.valor > 0)
  }, [doMes])

  const recentes = [...lancamentos]
    .sort((a, b) => (a.data < b.data ? 1 : -1))
    .slice(0, 6)

  const metaPrincipal = metas[0]

  function handlePerfilChange(campo, valor) {
    const novo = { ...perfil, [campo]: valor }
    setPerfil(novo)
    savePerfil(novo)
  }

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <p className="text-signal-cyan font-mono-num text-xs tracking-wider mb-1">TORRE DE CONTROLE</p>
          <h2 className="font-display text-2xl font-semibold">Como está sua vida hoje?</h2>
        </div>
        <div className="flex gap-3 text-xs">
          <input
            placeholder="Cidade atual"
            value={perfil.cidadeAtual}
            onChange={e => handlePerfilChange('cidadeAtual', e.target.value)}
            className="!w-36"
          />
          <input
            placeholder="Próximo destino"
            value={perfil.proximoDestino}
            onChange={e => handlePerfilChange('proximoDestino', e.target.value)}
            className="!w-36"
          />
        </div>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
        <Card label="Saldo geral" value={fmtMoeda(totalGeral.saldo)} accent={totalGeral.saldo >= 0 ? 'text-signal-cyan' : 'text-signal-red'} />
        <Card label="Faturamento do mês" value={fmtMoeda(totalMes.entradas)} />
        <Card label="Despesas do mês" value={fmtMoeda(totalMes.saidas)} />
        <Card
          label="Lucro do mês"
          value={fmtMoeda(totalMes.entradas - totalMes.saidas)}
          sub={`Margem: ${totalMes.margem.toFixed(1)}%`}
          accent={totalMes.entradas - totalMes.saidas >= 0 ? 'text-signal-cyan' : 'text-signal-red'}
        />
      </div>

      <div className="grid md:grid-cols-3 gap-4 mb-4">
        <div className="panel p-4 md:col-span-2">
          <p className="text-xs text-base-500 mb-3 font-mono-num">ENTRADAS VS SAÍDAS · ÚLTIMOS 6 MESES</p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={serieMeses}>
              <defs>
                <linearGradient id="ent" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4DD9C7" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#4DD9C7" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="sai" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#F2554B" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#F2554B" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#212936" strokeDasharray="3 3" vertical={false} />
              <XAxis dataKey="mes" stroke="#333F51" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#333F51" fontSize={11} tickLine={false} axisLine={false} width={40} />
              <Tooltip
                contentStyle={{ background: '#10151D', border: '1px solid #212936', borderRadius: 8, fontSize: 12 }}
                formatter={v => fmtMoeda(v)}
              />
              <Area type="monotone" dataKey="Entradas" stroke="#4DD9C7" fill="url(#ent)" strokeWidth={2} />
              <Area type="monotone" dataKey="Saídas" stroke="#F2554B" fill="url(#sai)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">DISTRIBUIÇÃO POR CAIXA · MÊS</p>
          {porCaixa.length === 0 ? (
            <p className="text-sm text-base-500 mt-8 text-center">Sem lançamentos este mês.</p>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={porCaixa} dataKey="valor" nameKey="nome" innerRadius={45} outerRadius={70} paddingAngle={3}>
                  {porCaixa.map((entry, i) => (
                    <Cell key={i} fill={CORES_CAIXA[entry.nome] || '#333F51'} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ background: '#10151D', border: '1px solid #212936', borderRadius: 8, fontSize: 12 }}
                  formatter={v => fmtMoeda(v)}
                />
              </PieChart>
            </ResponsiveContainer>
          )}
          <div className="flex flex-wrap gap-x-3 gap-y-1 mt-1 justify-center">
            {porCaixa.map((c, i) => (
              <span key={i} className="text-[11px] text-base-500 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full" style={{ background: CORES_CAIXA[c.nome] || '#333F51' }} />
                {c.nome}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">ÚLTIMOS LANÇAMENTOS</p>
          {recentes.length === 0 ? (
            <p className="text-sm text-base-500 py-6 text-center">Nenhum lançamento ainda. Comece em "Lançamentos".</p>
          ) : (
            <div className="space-y-2">
              {recentes.map(l => (
                <div key={l.id} className="flex items-center justify-between text-sm border-b border-base-700 last:border-0 pb-2 last:pb-0">
                  <div>
                    <p className="text-white">{l.categoria}</p>
                    <p className="text-[11px] text-base-500">{new Date(l.data + 'T00:00').toLocaleDateString('pt-BR')} · {l.caixa}</p>
                  </div>
                  <p className={`font-mono-num ${l.tipo === 'entrada' ? 'text-signal-cyan' : 'text-signal-red'}`}>
                    {l.tipo === 'entrada' ? '+' : '−'} {fmtMoeda(l.valor)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="panel p-4">
          <p className="text-xs text-base-500 mb-3 font-mono-num">META EM DESTAQUE</p>
          {!metaPrincipal ? (
            <p className="text-sm text-base-500 py-6 text-center">Nenhuma meta cadastrada ainda. Vá em "Metas".</p>
          ) : (
            <div>
              <div className="flex justify-between items-baseline mb-2">
                <p className="text-white font-medium">{metaPrincipal.nome}</p>
                <p className="text-xs text-base-500 font-mono-num">
                  {fmtMoeda(metaPrincipal.atual)} / {fmtMoeda(metaPrincipal.valor)}
                </p>
              </div>
              <div className="h-2.5 rounded-full bg-base-700 overflow-hidden">
                <div
                  className="h-full bg-signal-cyan rounded-full transition-all"
                  style={{ width: `${Math.min(100, (metaPrincipal.atual / metaPrincipal.valor) * 100 || 0)}%` }}
                />
              </div>
              <p className="text-right text-[11px] text-signal-cyan font-mono-num mt-1">
                {Math.min(100, ((metaPrincipal.atual / metaPrincipal.valor) * 100 || 0)).toFixed(0)}%
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
