import React, { useState } from 'react'
import { getMetas, addMeta, updateMeta, removeMeta } from '../lib/storage'
import { fmtMoeda } from '../lib/calc'

function vazio() {
  return { nome: '', valor: '', atual: '' }
}

export default function Metas() {
  const [metas, setMetas] = useState(getMetas())
  const [form, setForm] = useState(vazio())

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.nome || !form.valor) return
    const novo = addMeta({ nome: form.nome, valor: Number(form.valor), atual: Number(form.atual) || 0 })
    setMetas(prev => [...prev, novo])
    setForm(vazio())
  }

  function handleAtualizar(id, valor) {
    updateMeta(id, { atual: Number(valor) || 0 })
    setMetas(getMetas())
  }

  function handleRemover(id) {
    removeMeta(id)
    setMetas(prev => prev.filter(m => m.id !== id))
  }

  return (
    <div className="p-6 md:p-8 max-w-4xl">
      <header className="mb-6">
        <p className="text-signal-cyan font-mono-num text-xs tracking-wider mb-1">CONSTRUÇÃO DE PATRIMÔNIO</p>
        <h2 className="font-display text-2xl font-semibold">Metas</h2>
        <p className="text-sm text-base-500 mt-1">Reserva, equipamento, próxima viagem, investimentos — o que fizer sentido.</p>
      </header>

      <form onSubmit={handleSubmit} className="panel p-5 grid sm:grid-cols-[1fr_180px_180px_auto] gap-3 items-end mb-6">
        <div>
          <label className="block text-xs text-base-500 mb-1.5">Nome da meta</label>
          <input value={form.nome} onChange={e => setForm({ ...form, nome: e.target.value })} placeholder="Ex: Reserva de emergência" required />
        </div>
        <div>
          <label className="block text-xs text-base-500 mb-1.5">Valor alvo (R$)</label>
          <input type="number" step="0.01" value={form.valor} onChange={e => setForm({ ...form, valor: e.target.value })} required />
        </div>
        <div>
          <label className="block text-xs text-base-500 mb-1.5">Valor atual (R$)</label>
          <input type="number" step="0.01" value={form.atual} onChange={e => setForm({ ...form, atual: e.target.value })} />
        </div>
        <button type="submit" className="bg-signal-cyan text-base-950 font-semibold py-2.5 px-5 rounded-lg hover:opacity-90 transition h-fit">
          Criar meta
        </button>
      </form>

      <div className="space-y-3">
        {metas.length === 0 ? (
          <div className="panel p-10 text-center text-sm text-base-500">Nenhuma meta cadastrada ainda.</div>
        ) : (
          metas.map(m => {
            const pct = Math.min(100, ((m.atual / m.valor) * 100) || 0)
            return (
              <div key={m.id} className="panel p-4">
                <div className="flex items-start justify-between mb-2">
                  <p className="font-medium text-white">{m.nome}</p>
                  <button onClick={() => handleRemover(m.id)} className="text-xs text-base-500 hover:text-signal-red">remover</button>
                </div>
                <div className="h-2.5 rounded-full bg-base-700 overflow-hidden mb-2">
                  <div className="h-full bg-signal-cyan rounded-full transition-all" style={{ width: `${pct}%` }} />
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-base-500 font-mono-num">{fmtMoeda(m.atual)} de {fmtMoeda(m.valor)} · {pct.toFixed(0)}%</span>
                  <div className="flex items-center gap-2">
                    <span className="text-base-500">Atualizar valor:</span>
                    <input
                      type="number"
                      step="0.01"
                      defaultValue={m.atual}
                      onBlur={e => handleAtualizar(m.id, e.target.value)}
                      className="!w-28 !py-1"
                    />
                  </div>
                </div>
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}
