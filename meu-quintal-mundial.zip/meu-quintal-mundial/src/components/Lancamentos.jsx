import React, { useMemo, useState } from 'react'
import { getLancamentos, addLancamento, removeLancamento } from '../lib/storage'
import { TIPOS_ENTRADA_SUGERIDOS, CATEGORIAS_SAIDA, CAIXAS, FORMAS_PAGAMENTO, fmtMoeda, totais } from '../lib/calc'

const hoje = () => new Date().toISOString().slice(0, 10)

function vazio(tipo) {
  return {
    tipo,
    data: hoje(),
    valor: '',
    categoria: '',
    origem: '',
    caixa: tipo === 'entrada' ? 'Negócio' : 'Pessoal',
    formaPagamento: 'Pix',
    cidade: '',
    observacao: '',
  }
}

export default function Lancamentos() {
  const [lista, setLista] = useState(getLancamentos())
  const [tipo, setTipo] = useState('entrada')
  const [form, setForm] = useState(vazio('entrada'))
  const [filtroCaixa, setFiltroCaixa] = useState('Todas')

  function trocarTipo(t) {
    setTipo(t)
    setForm(vazio(t))
  }

  function handleSubmit(e) {
    e.preventDefault()
    if (!form.valor || !form.categoria) return
    const novo = addLancamento({ ...form, valor: Number(form.valor) })
    setLista(prev => [...prev, novo])
    setForm(vazio(tipo))
  }

  function handleRemover(id) {
    removeLancamento(id)
    setLista(prev => prev.filter(l => l.id !== id))
  }

  const listaFiltrada = useMemo(() => {
    const ordenada = [...lista].sort((a, b) => (a.data < b.data ? 1 : -1))
    return filtroCaixa === 'Todas' ? ordenada : ordenada.filter(l => l.caixa === filtroCaixa)
  }, [lista, filtroCaixa])

  const t = totais(listaFiltrada)

  return (
    <div className="p-6 md:p-8 max-w-6xl">
      <header className="mb-6">
        <p className="text-signal-cyan font-mono-num text-xs tracking-wider mb-1">MÓDULO FINANCEIRO</p>
        <h2 className="font-display text-2xl font-semibold">Lançamentos</h2>
        <p className="text-sm text-base-500 mt-1">Registre qualquer entrada — não só venda de fotos — e qualquer saída.</p>
      </header>

      <div className="grid lg:grid-cols-[360px_1fr] gap-5">
        <div className="panel p-5 h-fit">
          <div className="flex gap-2 mb-4">
            <button
              type="button"
              onClick={() => trocarTipo('entrada')}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${tipo === 'entrada' ? 'bg-signal-cyan text-base-950' : 'bg-base-800 text-base-500'}`}
            >
              ＋ Entrada
            </button>
            <button
              type="button"
              onClick={() => trocarTipo('saida')}
              className={`flex-1 py-2 rounded-lg text-sm font-medium transition ${tipo === 'saida' ? 'bg-signal-red text-base-950' : 'bg-base-800 text-base-500'}`}
            >
              － Saída
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-xs text-base-500 mb-1.5">
                {tipo === 'entrada' ? 'Tipo de serviço / origem da receita' : 'Categoria da despesa'}
              </label>
              {tipo === 'entrada' ? (
                <>
                  <input
                    list="tipos-entrada"
                    placeholder="Ex: Fotografia, aula, consultoria, freelancer..."
                    value={form.categoria}
                    onChange={e => setForm({ ...form, categoria: e.target.value })}
                    required
                  />
                  <datalist id="tipos-entrada">
                    {TIPOS_ENTRADA_SUGERIDOS.map(t => <option key={t} value={t} />)}
                  </datalist>
                </>
              ) : (
                <select value={form.categoria} onChange={e => setForm({ ...form, categoria: e.target.value })} required>
                  <option value="">Selecione...</option>
                  {CATEGORIAS_SAIDA.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              )}
              <p className="text-[11px] text-base-500 mt-1">
                {tipo === 'entrada' ? 'Digite qualquer tipo de serviço — o campo é livre.' : ''}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-base-500 mb-1.5">Valor (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={form.valor}
                  onChange={e => setForm({ ...form, valor: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="block text-xs text-base-500 mb-1.5">Data</label>
                <input type="date" value={form.data} onChange={e => setForm({ ...form, data: e.target.value })} required />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-base-500 mb-1.5">Caixa</label>
                <select value={form.caixa} onChange={e => setForm({ ...form, caixa: e.target.value })}>
                  {CAIXAS.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs text-base-500 mb-1.5">Forma de pagamento</label>
                <select value={form.formaPagamento} onChange={e => setForm({ ...form, formaPagamento: e.target.value })}>
                  {FORMAS_PAGAMENTO.map(f => <option key={f} value={f}>{f}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs text-base-500 mb-1.5">Cidade (opcional — liga à sua jornada)</label>
              <input
                placeholder="Ex: Ilhabela"
                value={form.cidade}
                onChange={e => setForm({ ...form, cidade: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-xs text-base-500 mb-1.5">Observação</label>
              <textarea
                rows={2}
                value={form.observacao}
                onChange={e => setForm({ ...form, observacao: e.target.value })}
              />
            </div>

            <button
              type="submit"
              className={`w-full py-2.5 rounded-lg font-semibold text-base-950 transition ${tipo === 'entrada' ? 'bg-signal-cyan hover:opacity-90' : 'bg-signal-red hover:opacity-90'}`}
            >
              Registrar {tipo === 'entrada' ? 'entrada' : 'saída'}
            </button>
          </form>
        </div>

        <div>
          <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
            <select value={filtroCaixa} onChange={e => setFiltroCaixa(e.target.value)} className="!w-44">
              <option value="Todas">Todas as caixas</option>
              {CAIXAS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <div className="flex gap-4 text-xs font-mono-num">
              <span className="text-signal-cyan">Entradas {fmtMoeda(t.entradas)}</span>
              <span className="text-signal-red">Saídas {fmtMoeda(t.saidas)}</span>
              <span className="text-white">Saldo {fmtMoeda(t.saldo)}</span>
            </div>
          </div>

          <div className="panel divide-y divide-base-700 max-h-[640px] overflow-y-auto">
            {listaFiltrada.length === 0 ? (
              <p className="text-sm text-base-500 py-10 text-center">Nenhum lançamento com esse filtro.</p>
            ) : (
              listaFiltrada.map(l => (
                <div key={l.id} className="flex items-center justify-between px-4 py-3 group">
                  <div className="min-w-0">
                    <p className="text-sm text-white truncate">{l.categoria}</p>
                    <p className="text-[11px] text-base-500 font-mono-num">
                      {new Date(l.data + 'T00:00').toLocaleDateString('pt-BR')} · {l.caixa} · {l.formaPagamento}
                      {l.cidade ? ` · ${l.cidade}` : ''}
                    </p>
                    {l.observacao && <p className="text-[11px] text-base-500 mt-0.5 truncate">{l.observacao}</p>}
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <p className={`font-mono-num text-sm ${l.tipo === 'entrada' ? 'text-signal-cyan' : 'text-signal-red'}`}>
                      {l.tipo === 'entrada' ? '+' : '−'} {fmtMoeda(l.valor)}
                    </p>
                    <button
                      onClick={() => handleRemover(l.id)}
                      className="text-base-500 hover:text-signal-red opacity-0 group-hover:opacity-100 transition text-xs"
                      title="Remover"
                    >
                      remover
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
