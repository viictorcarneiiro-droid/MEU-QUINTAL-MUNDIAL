/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        base: {
          950: '#070A0F',
          900: '#0A0E14',
          800: '#10151D',
          700: '#161C27',
          600: '#212936',
          500: '#333F51',
        },
        signal: {
          cyan: '#4DD9C7',
          blue: '#4C8DFF',
          amber: '#F2B84B',
          red: '#F2554B',
        },
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      backgroundImage: {
        grid: 'linear-gradient(rgba(77,217,199,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(77,217,199,0.05) 1px, transparent 1px)',
      },
      backgroundSize: {
        grid: '32px 32px',
      },
    },
  },
  plugins: [],
}
