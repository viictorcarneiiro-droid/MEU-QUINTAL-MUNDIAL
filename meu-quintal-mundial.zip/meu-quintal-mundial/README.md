# Meu Quintal Mundial — Torre de Controle

App pessoal (V1 + partes da V2/V3) para administrar receitas, despesas, viagens e metas.
Visual escuro/tecnológico, 100% em português.

## Rodando localmente

```bash
npm install
npm run dev
```

Abra o endereço que o terminal mostrar (normalmente http://localhost:5173).

## Publicando no Vercel

1. Suba esta pasta para um repositório no GitHub (privado, já que o app é de uso pessoal).
2. Em vercel.com → **Add New Project** → importe o repositório.
3. O Vercel detecta automaticamente que é um projeto Vite:
   - Build Command: `npm run build`
   - Output Directory: `dist`
4. Clique em Deploy. Pronto — você recebe uma URL própria.

Nada além disso é necessário: não há variáveis de ambiente nem backend.

## Como os dados são guardados

Este é um site estático. Não existe servidor nem banco de dados — tudo fica salvo
no `localStorage` **do navegador que você usar**. Isso quer dizer:

- Os dados **não sincronizam** entre celular e computador.
- Se você limpar os dados do site no navegador, perde o histórico.
- Use o botão **"↓ Backup"** no menu lateral regularmente para baixar um arquivo
  `.json` com tudo, e **"↑ Restaurar"** para importar esse arquivo (inclusive em
  outro dispositivo).

A senha de acesso (tela de login) também é local a este navegador — é um bloqueio
simples para evitar que alguém abra o app casualmente, não uma autenticação de
verdade com servidor. Se um dia você quiser dados sincronizados entre dispositivos
e uma senha real validada num servidor, o próximo passo natural é ligar o projeto
a um banco como o Supabase (ele se integra bem com Vercel) — posso te ajudar
com isso quando quiser evoluir para a V2.

## O que está incluso nesta versão

- **Login** local (V1)
- **Dashboard** com saldo, faturamento/despesas/lucro do mês, gráfico dos
  últimos 6 meses, distribuição por caixa e metas em destaque (V1)
- **Lançamentos**: qualquer tipo de entrada (campo livre, não só fotografia)
  e qualquer saída, com categoria, caixa (Negócio/Pessoal/Reserva/Investimento/
  Viagem), forma de pagamento e cidade opcional (V1 + base da V2)
- **Minha Jornada**: cadastro de cidades/viagens com custo de hospedagem e
  cálculo automático de quanto cada cidade gerou vs. custou, cruzando com os
  lançamentos marcados com aquela cidade (V2)
- **Metas** com barra de progresso (V3)
- **Relatório mensal** completo: receitas por tipo de serviço, despesas por
  categoria, resultado por caixa, resultado por cidade, top 5 despesas,
  comparação com o mês anterior e resumo operacional — pronto para
  imprimir/exportar em PDF pelo próprio navegador (item 17 do briefing)

## O que fica para as próximas versões

Dieta/alimentação, rotina pessoal, equipamentos, conteúdo, IA de análise e
alertas automáticos (V4 e V5 do seu planejamento original) ainda não estão
aqui — a arquitetura (dados em `src/lib/storage.js`, cálculos em
`src/lib/calc.js`, uma tela por módulo) foi pensada para você (ou eu, numa
próxima etapa) adicionar essas telas sem precisar refazer o que já existe.
